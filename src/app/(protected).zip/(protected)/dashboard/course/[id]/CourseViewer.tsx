"use client";
import { useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import {
  CheckCircle,
  Play,
  ChevronDown,
  Menu,
  X,
  Layers,
  List,
  Lock,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────
interface Lesson {
  id: string;
  title: string;
  duration: number;
  order: number;
  video_url?: string;
  content?: string;
}

interface Module {
  id: string;
  title: string;
  order: number;
  lessons: Lesson[];
}

interface Course {
  id: string;
  title: string;
  use_chapters?: boolean;
  products?: { title?: string; thumbnail?: string };
  modules: Module[];
}

// ─── Main Component ───────────────────────────────────────────────────────────
export function CourseViewer({
  course,
  initialLessonId,
  completedLessonIds,
}: {
  course: Course;
  initialLessonId: string;
  completedLessonIds: string[];
}) {
  const [completedIds, setCompletedIds] = useState<Set<string>>(
    new Set(completedLessonIds),
  );
  const [expanded, setExpanded] = useState<string[]>(
    course.modules.map((m) => m.id),
  );
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [lessonData, setLessonData] = useState<Lesson | null>(null);
  const [lessonLoading, setLessonLoading] = useState(false);
  const [markingDone, setMarkingDone] = useState(false);

  const useChapters = course.use_chapters !== false;
  const allLessons: Lesson[] = course.modules.flatMap((m) => m.lessons);
  const progress =
    allLessons.length > 0
      ? Math.round((completedIds.size / allLessons.length) * 100)
      : 0;

  const currentIndex = allLessons.findIndex((l) => l.id === activeLessonId);
  const prevLesson = currentIndex > 0 ? allLessons[currentIndex - 1] : null;
  const nextLesson =
    currentIndex >= 0 && currentIndex < allLessons.length - 1
      ? allLessons[currentIndex + 1]
      : null;

  // Buka lesson secara inline
  const openLesson = useCallback(
    async (lessonId: string) => {
      if (lessonId === activeLessonId) return;
      setActiveLessonId(lessonId);
      setLessonData(null);
      setLessonLoading(true);
      setMobileOpen(false);

      try {
        const res = await fetch(`/api/lesson/${lessonId}`);
        if (res.ok) {
          const data = await res.json();
          setLessonData(data);
        } else {
          // Fallback ke data dari course.modules
          const found = allLessons.find((l) => l.id === lessonId) ?? null;
          setLessonData(found);
        }
      } catch {
        const found = allLessons.find((l) => l.id === lessonId) ?? null;
        setLessonData(found);
      } finally {
        setLessonLoading(false);
      }
    },
    [activeLessonId, allLessons],
  );

  // Tandai lesson selesai
  const markComplete = useCallback(async () => {
    if (!activeLessonId || completedIds.has(activeLessonId)) return;
    setMarkingDone(true);
    try {
      await fetch(`/api/lesson/${activeLessonId}/complete`, { method: "POST" });
      setCompletedIds((prev) => new Set([...prev, activeLessonId]));
    } finally {
      setMarkingDone(false);
    }
  }, [activeLessonId, completedIds]);

  // ─── Sidebar ──────────────────────────────────────────────────────────────
  const SidebarContent = () => (
    <>
      <div className="p-4 sm:p-5 border-b border-white/[0.07]">
        <h2 className="font-syne font-bold text-sm leading-snug mb-3">
          {course.products?.title || course.title}
        </h2>
        <div className="flex items-center gap-2 mb-1">
          <div className="flex-1 h-1.5 bg-bg rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-accent to-accent-light rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-xs font-bold text-accent-light">
            {progress}%
          </span>
        </div>
        <p className="text-xs text-text-muted">
          {completedIds.size}/{allLessons.length} lesson
        </p>
      </div>

      <div className="p-2 flex-1 overflow-auto">
        {/* Flat mode */}
        {!useChapters &&
          course.modules[0]?.lessons?.map((l) => {
            const done = completedIds.has(l.id);
            const active = activeLessonId === l.id;
            return (
              <button
                key={l.id}
                onClick={() => openLesson(l.id)}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg mb-1 text-left transition-all text-xs",
                  active
                    ? "bg-accent/10 text-accent-light"
                    : done
                      ? "text-green-400 hover:bg-green-500/5"
                      : "text-text-muted hover:bg-white/5 hover:text-[#EEEEFF]",
                )}
              >
                <span className="shrink-0">
                  {done ? (
                    <CheckCircle size={13} className="text-green-400" />
                  ) : active ? (
                    <Play
                      size={13}
                      className="text-accent-light fill-accent-light"
                    />
                  ) : (
                    <Play size={13} className="text-text-dim" />
                  )}
                </span>
                <span className="flex-1 truncate">{l.title}</span>
                {l.duration > 0 && (
                  <span className="text-text-dim shrink-0">
                    {Math.floor(l.duration / 60)}m
                  </span>
                )}
              </button>
            );
          })}

        {/* Chapter mode */}
        {useChapters &&
          course.modules.map((m, mi) => (
            <div key={m.id} className="mb-1">
              <button
                onClick={() =>
                  setExpanded((p) =>
                    p.includes(m.id)
                      ? p.filter((x) => x !== m.id)
                      : [...p, m.id],
                  )
                }
                className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg hover:bg-white/5 text-left transition-colors"
              >
                <span className="w-5 h-5 rounded bg-accent/10 flex items-center justify-center text-[10px] font-bold text-accent-light shrink-0">
                  {mi + 1}
                </span>
                <span className="flex-1 text-xs font-semibold text-text-muted truncate">
                  {m.title}
                </span>
                <ChevronDown
                  size={13}
                  className={cn(
                    "text-text-dim transition-transform shrink-0",
                    expanded.includes(m.id) && "rotate-180",
                  )}
                />
              </button>

              {expanded.includes(m.id) && (
                <div className="space-y-0.5 ml-2">
                  {m.lessons.map((l) => {
                    const done = completedIds.has(l.id);
                    const active = activeLessonId === l.id;
                    return (
                      <button
                        key={l.id}
                        onClick={() => openLesson(l.id)}
                        className={cn(
                          "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all text-xs",
                          active
                            ? "bg-accent/10 text-accent-light"
                            : done
                              ? "text-green-400 hover:bg-green-500/5"
                              : "text-text-muted hover:bg-white/5 hover:text-[#EEEEFF]",
                        )}
                      >
                        <span className="shrink-0">
                          {done ? (
                            <CheckCircle size={12} className="text-green-400" />
                          ) : active ? (
                            <Play
                              size={12}
                              className="text-accent-light fill-accent-light"
                            />
                          ) : (
                            <Play size={12} className="text-text-dim" />
                          )}
                        </span>
                        <span className="flex-1 truncate">{l.title}</span>
                        {l.duration > 0 && (
                          <span className="text-text-dim shrink-0">
                            {Math.floor(l.duration / 60)}m
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
      </div>
    </>
  );

  // ─── Konten Utama (area kanan) ────────────────────────────────────────────
  const MainContent = () => {
    // Halaman welcome sebelum lesson dipilih
    if (!activeLessonId) {
      return (
        <div className="flex items-center justify-center h-full p-8">
          <div className="text-center max-w-md">
            <div className="text-5xl mb-4">📚</div>
            <h2 className="font-syne font-bold text-xl mb-2">
              {course.products?.title || course.title}
            </h2>
            <p className="text-text-muted text-sm mb-6">
              {completedIds.size > 0
                ? `${completedIds.size} lesson selesai. Lanjutkan!`
                : "Pilih lesson dari sidebar untuk mulai belajar"}
            </p>
            {initialLessonId && (
              <button
                onClick={() => openLesson(initialLessonId)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-cta text-black font-syne font-bold rounded-xl hover:bg-cta-hover transition-all"
              >
                <Play size={16} />
                {completedIds.size > 0 ? "Lanjut Belajar" : "Mulai Belajar"}
              </button>
            )}
          </div>
        </div>
      );
    }

    // Loading
    if (lessonLoading) {
      return (
        <div className="flex items-center justify-center h-full">
          <Loader2 size={28} className="animate-spin text-accent-light" />
        </div>
      );
    }

    const lesson =
      lessonData ?? allLessons.find((l) => l.id === activeLessonId);
    if (!lesson) return null;

    const isDone = completedIds.has(lesson.id);

    return (
      <div className="flex flex-col h-full overflow-y-auto">
        {/* Video */}
        <div className="w-full bg-black aspect-video flex-shrink-0 relative">
          {lesson.video_url ? (
            <iframe
              key={lesson.id}
              src={lesson.video_url}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center gap-3 text-text-muted">
              <Lock size={32} className="text-text-dim" />
              <p className="text-sm">Video tidak tersedia</p>
            </div>
          )}
        </div>

        {/* Info lesson */}
        <div className="p-5 sm:p-6 flex-1">
          <div className="flex items-start gap-3 mb-4">
            <div className="flex-1">
              <p className="text-xs text-text-muted mb-1">
                Lesson {currentIndex + 1} dari {allLessons.length}
              </p>
              <h1 className="font-syne font-bold text-lg leading-snug">
                {lesson.title}
              </h1>
              {lesson.duration > 0 && (
                <p className="text-xs text-text-muted mt-1">
                  {Math.floor(lesson.duration / 60)} menit
                </p>
              )}
            </div>
            {isDone && (
              <span className="flex items-center gap-1.5 text-xs text-green-400 bg-green-500/10 px-2.5 py-1 rounded-full shrink-0 mt-1">
                <CheckCircle size={12} /> Selesai
              </span>
            )}
          </div>

          {/* Konten teks opsional */}
          {lesson.content && (
            <div
              className="prose prose-invert prose-sm max-w-none text-text-muted mb-6"
              dangerouslySetInnerHTML={{ __html: lesson.content }}
            />
          )}

          {/* Navigasi bawah */}
          <div className="flex items-center gap-3 pt-4 border-t border-white/[0.07]">
            <button
              onClick={() => prevLesson && openLesson(prevLesson.id)}
              disabled={!prevLesson}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-white/[0.07] text-xs font-semibold text-text-muted hover:bg-white/5 disabled:opacity-30 disabled:pointer-events-none transition-all"
            >
              <ChevronLeft size={14} /> Sebelumnya
            </button>

            <div className="flex-1" />

            {!isDone && (
              <button
                onClick={markComplete}
                disabled={markingDone}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-green-500/30 text-xs font-semibold text-green-400 hover:bg-green-500/10 disabled:opacity-50 transition-all"
              >
                {markingDone ? (
                  <Loader2 size={13} className="animate-spin" />
                ) : (
                  <CheckCircle size={13} />
                )}
                Tandai Selesai
              </button>
            )}

            <button
              onClick={() => nextLesson && openLesson(nextLesson.id)}
              disabled={!nextLesson}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cta text-black text-xs font-bold hover:bg-cta-hover disabled:opacity-30 disabled:pointer-events-none transition-all"
            >
              Selanjutnya <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    );
  };

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-bg">
      {/* Mobile top bar */}
      <div className="lg:hidden sticky top-0 z-30 bg-surface/95 backdrop-blur-xl border-b border-white/[0.07] px-4 h-12 flex items-center justify-between">
        <div className="flex items-center gap-2 min-w-0">
          {useChapters ? (
            <Layers size={14} className="text-text-dim shrink-0" />
          ) : (
            <List size={14} className="text-text-dim shrink-0" />
          )}
          <span className="font-syne font-bold text-sm truncate">
            {activeLessonId
              ? (lessonData?.title ??
                allLessons.find((l) => l.id === activeLessonId)?.title ??
                course.products?.title)
              : course.products?.title}
          </span>
        </div>
        <button
          onClick={() => setMobileOpen(true)}
          className="flex items-center gap-1.5 text-xs text-accent-light shrink-0 ml-3"
        >
          <Menu size={15} /> Materi
        </button>
      </div>

      {/* Mobile sidebar drawer */}
      {mobileOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/60 z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
          />
          <div className="fixed top-0 right-0 bottom-0 w-80 bg-surface border-l border-white/[0.07] z-50 lg:hidden flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-white/[0.07]">
              <span className="font-syne font-bold text-sm">Daftar Materi</span>
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/5 text-text-muted"
              >
                <X size={16} />
              </button>
            </div>
            <div className="flex-1 overflow-auto flex flex-col">
              <SidebarContent />
            </div>
          </div>
        </>
      )}

      {/* Desktop: sidebar kiri + konten inline kanan */}
      <div className="hidden lg:grid lg:grid-cols-[300px_1fr] min-h-[calc(100vh-64px)]">
        <aside className="bg-surface border-r border-white/[0.07] sticky top-16 h-[calc(100vh-64px)] overflow-y-auto flex flex-col">
          <SidebarContent />
        </aside>
        <main className="h-[calc(100vh-64px)] overflow-hidden flex flex-col">
          <MainContent />
        </main>
      </div>

      {/* Mobile: konten full width */}
      <div className="lg:hidden flex flex-col">
        <MainContent />
      </div>
    </div>
  );
}
