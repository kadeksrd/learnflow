"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  CheckCircle,
  Play,
  ChevronDown,
  Menu,
  X,
  Layers,
  List,
} from "lucide-react";

export function CourseViewer({
  course,
  initialLessonId,
  completedLessonIds,
}: {
  course: any;
  initialLessonId: string;
  completedLessonIds: string[];
}) {
  const router = useRouter();
  const [completedIds] = useState(new Set(completedLessonIds));
  const [expanded, setExpanded] = useState<string[]>(
    course.modules.map((m: any) => m.id),
  );
  const [mobileOpen, setMobileOpen] = useState(false);

  const useChapters = course.use_chapters !== false;
  const allLessons = course.modules.flatMap((m: any) => m.lessons);
  const progress =
    allLessons.length > 0
      ? Math.round((completedIds.size / allLessons.length) * 100)
      : 0;

  const SidebarContent = () => (
    <>
      <div className="p-4 sm:p-5 border-b border-white/[0.07]">
        <h2 className="font-syne font-bold text-sm leading-snug mb-3">
          {course.products?.title || course.title}
        </h2>
        <div className="flex items-center gap-2 mb-1">
          <div className="flex-1 h-1.5 bg-bg rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-accent to-accent-light rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-xs font-bold text-accent-light">
            {progress}%
          </span>
        </div>
        <p className="text-xs text-text-muted">
          {completedIds.size}/{allLessons.length} lesson
        </p>
      </div>

      <div className="p-2 flex-1 overflow-auto">
        {/* Flat mode: no grouping */}
        {!useChapters &&
          course.modules[0]?.lessons?.map((l: any) => {
            const done = completedIds.has(l.id);
            return (
              <button
                key={l.id}
                onClick={() => {
                  router.push(`/lesson/${l.id}`);
                  setMobileOpen(false);
                }}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg mb-1 text-left transition-all text-xs",
                  done
                    ? "text-green-400 hover:bg-green-500/5"
                    : "text-text-muted hover:bg-white/5 hover:text-[#EEEEFF]",
                )}
              >
                <span className="shrink-0">
                  {done ? (
                    <CheckCircle size={13} className="text-green-400" />
                  ) : (
                    <Play size={13} className="text-text-dim" />
                  )}
                </span>
                <span className="flex-1 truncate">{l.title}</span>
                {l.duration > 0 && (
                  <span className="text-text-dim shrink-0">
                    {Math.floor(l.duration / 60)}m
                  </span>
                )}
              </button>
            );
          })}

        {/* Chapter mode: grouped */}
        {useChapters &&
          course.modules.map((m: any, mi: number) => (
            <div key={m.id} className="mb-1">
              <button
                onClick={() =>
                  setExpanded((p) =>
                    p.includes(m.id)
                      ? p.filter((x) => x !== m.id)
                      : [...p, m.id],
                  )
                }
                className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg hover:bg-white/5 text-left transition-colors"
              >
                <span className="w-5 h-5 rounded bg-accent/10 flex items-center justify-center text-[10px] font-bold text-accent-light shrink-0">
                  {mi + 1}
                </span>
                <span className="flex-1 text-xs font-semibold text-text-muted truncate">
                  {m.title}
                </span>
                <ChevronDown
                  size={13}
                  className={cn(
                    "text-text-dim transition-transform shrink-0",
                    expanded.includes(m.id) && "rotate-180",
                  )}
                />
              </button>
              {expanded.includes(m.id) && (
                <div className="space-y-0.5 ml-2">
                  {m.lessons.map((l: any) => {
                    const done = completedIds.has(l.id);
                    return (
                      <button
                        key={l.id}
                        onClick={() => {
                          router.push(`/lesson/${l.id}`);
                          setMobileOpen(false);
                        }}
                        className={cn(
                          "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all text-xs",
                          done
                            ? "text-green-400 hover:bg-green-500/5"
                            : "text-text-muted hover:bg-white/5 hover:text-[#EEEEFF]",
                        )}
                      >
                        <span className="shrink-0">
                          {done ? (
                            <CheckCircle size={12} className="text-green-400" />
                          ) : (
                            <Play size={12} className="text-text-dim" />
                          )}
                        </span>
                        <span className="flex-1 truncate">{l.title}</span>
                        {l.duration > 0 && (
                          <span className="text-text-dim shrink-0">
                            {Math.floor(l.duration / 60)}m
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-bg">
      <div className="lg:hidden sticky top-0 z-30 bg-surface/95 backdrop-blur-xl border-b border-white/[0.07] px-4 h-12 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {useChapters ? (
            <Layers size={14} className="text-text-dim" />
          ) : (
            <List size={14} className="text-text-dim" />
          )}
          <span className="font-syne font-bold text-sm truncate">
            {course.products?.title}
          </span>
        </div>
        <button
          onClick={() => setMobileOpen(true)}
          className="flex items-center gap-1.5 text-xs text-accent-light shrink-0 ml-3"
        >
          <Menu size={15} /> Materi
        </button>
      </div>

      {mobileOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/60 z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
          />
          <div className="fixed top-0 right-0 bottom-0 w-80 bg-surface border-l border-white/[0.07] z-50 lg:hidden flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-white/[0.07]">
              <span className="font-syne font-bold text-sm">Daftar Materi</span>
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/5 text-text-muted"
              >
                <X size={16} />
              </button>
            </div>
            <div className="flex-1 overflow-auto">
              <SidebarContent />
            </div>
          </div>
        </>
      )}

      <div className="hidden lg:grid lg:grid-cols-[300px_1fr] min-h-[calc(100vh-64px)]">
        <aside className="bg-surface border-r border-white/[0.07] sticky top-16 h-[calc(100vh-64px)] overflow-y-auto flex flex-col">
          <SidebarContent />
        </aside>
        {/* ubah disini  */}
        <main className="flex items-center justify-center p-8">
          <div className="text-center max-w-md">
            <div className="text-5xl mb-4">📚</div>
            <h2 className="font-syne font-bold text-xl mb-2">
              {course.products?.title}
            </h2>
            <p className="text-text-muted text-sm mb-6">
              {completedIds.size > 0
                ? `${completedIds.size} lesson selesai. Lanjutkan!`
                : "Pilih lesson untuk mulai belajar"}
            </p>
            {initialLessonId && (
              <button
                onClick={() => router.push(`/lesson/${initialLessonId}`)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-cta text-black font-syne font-bold rounded-xl hover:bg-cta-hover transition-all"
              >
                <Play size={16} />{" "}
                {completedIds.size > 0 ? "Lanjut Belajar" : "Mulai Belajar"}
              </button>
            )}
          </div>
        </main>
      </div>

      <div className="lg:hidden flex flex-col items-center justify-center p-6 min-h-[60vh]">
        <div className="text-center max-w-sm">
          <div className="text-4xl mb-4">📚</div>
          <h2 className="font-syne font-bold text-lg mb-2">
            {course.products?.title}
          </h2>
          <p className="text-text-muted text-sm mb-5">
            {completedIds.size > 0
              ? `${completedIds.size}/${allLessons.length} selesai`
              : "Pilih lesson untuk mulai"}
          </p>
          {initialLessonId && (
            <button
              onClick={() => router.push(`/lesson/${initialLessonId}`)}
              className="inline-flex items-center gap-2 px-5 py-3 bg-cta text-black font-syne font-bold rounded-xl text-sm"
            >
              <Play size={14} /> {completedIds.size > 0 ? "Lanjut" : "Mulai"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

{
  /* <LessonContent
      lesson={lesson}
      course={{ ...course, modules }}
      prevLesson={prevLesson}
      nextLesson={nextLesson}
      isCompleted={completedSet.has(params.id)}
      completedLessonIds={Array.from(completedSet)}
    /> */
}
